/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strchr.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: tessaadi <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/10/13 22:22:56 by tessaadi          #+#    #+#             */
/*   Updated: 2025/10/13 22:30:28 by tessaadi         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h"

char	*ft_strchr(const char *s, int c)
{
	size_t	i;
	char	letter;

	letter = (char)c;
	i = 0;
	while (s[i])
	{
		if (s[i] == letter)
			return (&s[i]);
		i++;
	}
	return (NULL);
}
