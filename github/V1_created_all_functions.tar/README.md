# libft


# Questios :
```

1. "always check that the functions used in your library comply with the project
guidelines. " What thisword means?

2. what is "bus error" mean and ?

3. what is the defination of "bus error" "segmentation fault" "double free" ?

4. " If the subject requires it, you must submit a Makefile which will compile your
source files to the required output with the flags -Wall, -Wextra and -Werror, use
cc, and your Makefile must not relink."

- what " must not relink." means ?

5. "• To turn in bonuses to your project, you must include a rule bonus to your Makefile,
which will add all the various headers, libraries or functions that are forbidden on
the main part of the project. Bonuses must be in a different file _bonus.{c/h} if
the subject does not specify anything else. Mandatory and bonus part evaluation
is done separately."

- i dont understnd this.

6. "• If your project allows you to use your libft, you must copy its sources and its
associated Makefile in a libft folder with its associated Makefile. Your project’s
Makefile must compile the library by using its Makefile, then compile the project."

7. " We encourage you to create test programs for your project even though this work
won’t have to be submitted and won’t be graded. It will give you a chance
to easily test your work and your peers’ work. You will find those tests especially
useful during your defence. Indeed, during defence, you are free to use your tests
and/or the tests of the peer you are evaluating."

- how the tests files will not be evaluating should i add them to a specific folder ?

8. "Depending on your current operating system, the ’calloc’ function’s
behavior may differ from its man page description. Follow this
rule instead: If nmemb or size is 0, then calloc() returns a unique
pointer value that can be successfully passed to free()."

9. "Some functions that you must reimplement, such as strlcpy, strlcat,
and bzero, are not included by default in the GNU C Library (glibc).
To test them against the system standard, you may need to include
<bsd/string.h> and compile with the -lbsd flag.
This behaviour is specific to glibc systems. If you are curious,
take the opportunity to explore the differences between glibc and BSD
libc."

10. what is the deffrent between "SOURCES := $(wildcard *.c)" and"SOURCES : $(wildcard *.c)" without equal sign ?

11. part II ft_strmapi :

"Applies the function f to each character of the
string s, passing its index as the first argument
and the character itself as the second. A new
string is created (using malloc(3)) to store the
results from the successive applications of f."

    - how to know if f applications is successive ??
```

# Foridden
```
1. Declaring global variables is strictly forbidden.

2. "You must use the ar command to create your library. The use of libtool is strictly
forbidden."

3. "Some of the function prototypes you need to reimplement use the
’restrict’ qualifier. This keyword is part of the C99 standard.
Therefore, it is forbidden to include it in your own prototypes or to
compile your code with the -std=c99 flag."

4. dont forget the prefix in function file name and in function name
```


# Instructions :
```
1. Project must be written in c.

2. use norminette at the root of the project.

3. "Your functions should not quit unexpectedly (segmentation fault, bus error, double
free, etc) apart from undefined behaviors. If this happens, your project will be
considered non functional and will receive a 0 during the evaluation."

4. must free the meory after alocated if neccessary.

5. use this flafgs in Makefile needed -Wall -Wextra -Werror and use cc compiler

6. the Makefile must at leat contain these rules 
"$(NAME) , all, clean, fclean, re"

7. all c files must be named with ft_ prefix

8. if you need secondary functions define them as static

9. " All files must be placed at the root of your repository."

10. "Submitting unused files is not allowed."
- run "ls -la" and delete hidden files before push

11. "Every .c file must compile with the following flags: -Wall -Wextra -Werror."

12. Your libft.a must be created at the root of your repository.

13. functions must start with the
’ft_’ prefix. For example, strlen becomes ft_strlen.

14. "To implement the two following functions, you will use malloc()
• calloc • strdup"

15. "In your Makefile, add a make bonus rule to add the bonus functions in your libft.a"

16. double check bonus part and bonus files name and bonus make rule
```


# Algorithme :
```
1. test all the functions even the submitted functions atoi in pool its notthe atoi in stdlib.h

2. what is the deffrece between glibc and BSD libc

3. o double-check the names of
your files to ensure they are correct.

4. Place all your files at the root of your repository.

5. dont forget typecasting

6. convert ft_atoi pool to atoi atdlib 

7. convert ft_strstr to ft_strnstr

8. dont forget the prefix in function file name and in function name

9. write all functions prototype in header file libft.h

10. update 42 header in all files and check if it have the same name

11. dont forget norminette

12. make sure all c files has the header file libft.h

13. in copy memory area should i use char *str or unsigned char *str in casting ?
    Answer : 13. use unsigned char always

14. define this :
    "BSD systems and isn’t part of the C standard."

15. in bonus make rule should we just update the libft.a or create new libft.a has only the bonus object files ?

16. Shoud i use malloc if function or use calloc ?
```

# Functions Name :
```
1. part I 23 functions

1. isalpha
2. isdigit
3. isalnum
4. isascii
5. isprint
6. strlen
7. memset
8. bzero
9. memcpy
10. memmove
11. strlcpy
12. strlcat
13. toupper
14. tolower
15. strchr
16. strrchr
17. strncmp
18. memchr
19. memcmp
20. strnstr
21. atoi
22. calloc
23. strdup

_________________________________________________________________________

2. part II 11 functions

1. ft_substr
2. ft_strjoin
3. ft_strtrim
4. ft_split
5. ft_itoa
6. ft_strmapi
7. ft_striteri
8. ft_putchar_fd
9. ft_putstr_fd
10. ft_putendl_fd
11. ft_putnbr_fd

_____________________________________________________________________________

3. Bonus part 9 functions

1. ft_lstnew
2. ft_lstadd_front
3. ft_lstsize
4. ft_lstlast
5. ft_lstadd_back
6. ft_lstdelone
7. ft_lstclear
8. ft_lstiter
9. ft_lstmap


```

# Functios Prototypes :
```
1. part I 21 functions

1. int isalpha(int c); ✅
2. int isdigit(int c); ✅
3. int isalnum(int c); ✅
4. int isascii(int c); ✅
5. int isprint(int c); ✅
6. size_t strlen(const char *s); ✅
7. void *memset(void *s, int c, size_t n); ✅
8. void bzero(void *s, size_t n);  ✅
9. void *memcpy(void *dest, const void *src, size_t n); ✅
10. void *memmove(void *dest, const void *src, size_t n); 
11. size_t strlcpy(char *dst, const char *src, size_t size); ✅
12. size_t strlcat(char *dst, const char *src, size_t size); ✅
13. int toupper(int c); ✅
14. int tolower(int c); ✅
15. char *strchr(const char *s, int c); ✅
16. char *strrchr(const char *s, int c); ✅
17. int strncmp(const char *s1, const char *s2, size_t n); ✅
18. void *memchr(const void *s, int c, size_t n); ✅ 
19. int memcmp(const void *s1, const void *s2, size_t n); ✅
20. char *strnstr(const char *big, const char *little, size_t len); ✅
21. int atoi(const char *nptr); ✅
22. void *calloc(size_t nmemb, size_t size); ✅
23. char *strdup(const char *s); ✅

_________________________________________________________________________

2. part II 11 functions

1. char *ft_substr(char const *s, unsigned int start, size_t len); ✅
2. char *ft_strjoin(char const *s1, char const *s2);  ✅
3. char *ft_strtrim(char const *s1, char const *set); ✅
4. char **ft_split(char const *s, char c); ✅
5. char *ft_itoa(int n); ✅
6. char *ft_strmapi(char const *s, char (*f)(unsigned int, char)); ✅
7. void ft_striteri(cha     r *s, void (*f)(unsigned int, char*)); ✅
8. void ft_putchar_fd(char c, int fd); ✅
9. void ft_putstr_fd(char *s, int fd); ✅
10. void ft_putendl_fd(char *s, int fd); ✅
11. void ft_putnbr_fd(int n, int fd); ✅

3. bonus part 

1. t_list *ft_lstnew(void *content); ✅
2. void ft_lstadd_front(t_list **lst, t_list *new); ✅
3. int ft_lstsize(t_list *lst); ✅
4. t_list *ft_lstlast(t_list *lst); ✅
5. void ft_lstadd_back(t_list **lst, t_list *new);  ✅
6. void ft_lstdelone(t_list *lst, void (*del)(void*)); ✅
7. void ft_lstclear(t_list **lst, void (*del)(void*)); ✅
8. void ft_lstiter(t_list *lst, void (*f)(void *)); ✅
9. t_list *ft_lstmap(t_list *lst, void *(*f)(void *), void (*del)(void *)); 
```



# Answers:

10. what is the deffrent between "SOURCES := $(wildcard *.c)" and"SOURCES : $(wildcard *.c)" without equal sign ?

```makefile
# Using :=
SOURCES := $(wildcard *.c)
# Even if you add a new .c file after this, SOURCES won't change

# Using :
SOURCES : $(wildcard *.c)
# SOURCES will be re-evaluated each time it's used, always showing the current .c files
```

For most cases, := is preferred because it avoids unnecessary re-evaluations and is generally more efficient. However, if you need dynamic updates (e.g., in very complex build setups), you might opt for :.



# Test Cases :
```
# ft_memset :
void    *ft_memset(void *s, int c, size_t n);

- check if c is ascii
- what should i return if c is not ascii ?

# ft_memcpy :
void    *ft_memcpy(void *dest, const void *src, size_t n);

- what is the behavier of this function if memory src and dest overlabed ?

# ft_memcmp :
int ft_memcmp(const void *s1, const void *s2, size_t n);

- it need visaulation in this condition 
while (i < n - 1 && str1[i] == str2[i])
{
    i++;
}

# ft_strchr && ft_strrchr : 
char *ft_strchr(const char *s, int c);

- what the function do if c is not ascii ?
- what is the behievyor of the function if c deosnt exict in s ?
        - it return NULL if the charactr in not found

# ft_memchr :
void    *ft_memchr(const void *s, int c, size_t n);

- if the the value of c is higher than 255 hat should i do ?

# ft_substr :
char *ft_substr(char const *s, unsigned int start, size_t len);

- if (start > len) what should i return ?

# ft_split :
- i need to add ft_strncpy

# ft_lstmap :
t_list *ft_lstmap(t_list *lst, void *(*f)(void *), void (*del)(void *));
    - we dont need the function del ?   

# calloc :
    void *calloc(size_t nmemb, size_t size);
    - if size * nmemb == 0 what should i do ?
```