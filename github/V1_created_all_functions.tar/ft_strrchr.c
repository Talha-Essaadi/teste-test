/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strrchr.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: tessaadi <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/10/13 22:31:09 by tessaadi          #+#    #+#             */
/*   Updated: 2025/10/13 22:36:01 by tessaadi         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h"

char	*ft_strrchr(const char *s, int c)
{
	size_t	i;
	char	letter;

	i = ft_strlen(s) - 1;
	letter = (char)c;
	while (i >= 0)
	{
		if (s[i] == letter)
			return (&s[i]);
		i--;
	}
	return (NULL);
}
